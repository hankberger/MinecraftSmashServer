#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;
in vec2 smashQuad;
in vec2 smashPosition;
flat in vec2 smashScreen;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    // Staged vertex buffers may start a draw at any corner index. Derivative
    // lengths also handle that UV rotation, rather than assuming corner zero.
    vec2 extent = vec2(length(dFdx(smashPosition)), length(dFdy(smashPosition)))
        / max(vec2(length(dFdx(smashQuad)), length(dFdy(smashQuad))), vec2(0.000001));
    bool horizontal = abs(extent.x - 344.0) < 0.1 && abs(extent.y - 1.0) < 0.1;
    bool vertical = abs(extent.x - 1.0) < 0.1 && abs(extent.y - 168.0) < 0.1;
    if (all(greaterThan(color, vec4(0.999))) && (horizontal || vertical)) discard;
    // Screen.extractTransparentBackground's C0101010 -> D0101010 gradient.
    // Only the full-screen native dimmer is removed, not dark controls or text.
    bool fullscreen = all(lessThan(abs(extent - smashScreen), vec2(1.1)));
    bool dimmer = all(lessThan(abs(color.rgb - vec3(16.0 / 255.0)), vec3(0.001)))
        && color.a >= 191.5 / 255.0 && color.a <= 208.5 / 255.0;
    if (fullscreen && dimmer) discard;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
