#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    vec2 clipCorner = abs(gl_Position.xy / gl_Position.w);
    // Screen dimensions round up to whole GUI pixels. At GUI scale 3, for
    // example, the far edge can project slightly beyond the viewport.
    vec2 oneGuiPixel = abs(vec2(ProjMat[0][0], ProjMat[1][1]));
    bool screenCorner = all(lessThan(abs(clipCorner - vec2(1.0)), oneGuiPixel * 1.01 + vec2(0.00001)));
    bool dimRgb = all(lessThan(abs(Color.rgb - vec3(16.0 / 255.0)), vec3(0.0001)));
    bool dimAlpha = abs(Color.a - 192.0 / 255.0) < 0.0001
                 || abs(Color.a - 208.0 / 255.0) < 0.0001;
    if (screenCorner && dimRgb && dimAlpha) {
        vertexColor.a = 0.0;
    }

}
